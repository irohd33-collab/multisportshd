import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';

const SPORT_ICON = {
  football: '⚽', basketball: '🏀', tennis: '🎾', ice_hockey: '🏒', table_tennis: '🏓',
  volleyball: '🏐', baseball: '⚾', cricket: '🏏', rugby: '🏉', handball: '🤾',
  futsal: '⚽', badminton: '🏸', golf: '⛳', boxing: '🥊', darts: '🎯',
  formula_1: '🏎️', horse_racing: '🏇', motorsport: '🏎️', snooker: '🎱', sports_channels: '📺',
};

function fmtTime(ts) {
  return new Date(ts).toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' });
}

function fmtDate(ts) {
  return new Date(ts).toLocaleDateString('tr-TR', { weekday: 'short', day: 'numeric', month: 'short' });
}

// 48 saat içindeyse göreli süre, daha uzaksa "gün saat" — absürt "197 sa" görünmez
function relTime(ts) {
  const diff = Math.round((ts - Date.now()) / 60000);
  if (!Number.isFinite(diff) || diff <= 0) return 'başladı';
  if (diff < 60) return `${diff} dk sonra`;
  const h = Math.floor(diff / 60);
  if (h < 48) {
    const r = diff % 60;
    return r ? `${h} sa ${r} dk sonra` : `${h} sa sonra`;
  }
  const days = Math.round(diff / 1440);
  return `${fmtDate(ts)} · ${days} gün sonra`;
}

function StatusBadge({ e }) {
  if (e.status === 'live') {
    return <span className="badge badge-live"><span className="badge-dot" /> CANLI {e.game_time ? <span className="badge-time">{String(e.game_time).split('.')[0]}</span> : null}</span>;
  }
  if (e.status === 'upcoming' && e.start) {
    const ts = new Date(e.start).getTime();
    const hoursAway = (ts - Date.now()) / 3600000;
    // 48 saat içinde: saat + göreli; daha uzak: gün + saat
    const label = hoursAway < 48
      ? `🕐 ${fmtTime(e.start)} · ${relTime(e.start)}`
      : `📅 ${fmtDate(e.start)} ${fmtTime(e.start)}`;
    return <span className="badge badge-upcoming">{label}</span>;
  }
  if (e.start) {
    return <span className="badge badge-muted">🕐 {fmtTime(e.start)}</span>;
  }
  return <span className="badge badge-muted">Yayın var</span>;
}

function StreamCard({ e }) {
  const icon = SPORT_ICON[e.sport_key] || '📺';
  const teams = e.away ? `${e.home} vs ${e.away}` : e.home;
  return (
    <Link to={`/watch/${e.stream_id}`} className="card" target="_blank" rel="noopener noreferrer">
      <div className="card-media">
        <img className="card-cover" src={e.ai_cover || e.cover || `/api/stream/${e.stream_id}/cover?home=${encodeURIComponent(e.home)}&away=${encodeURIComponent(e.away)}&league=${encodeURIComponent(e.league)}`} alt="" loading="lazy" />
        <StatusBadge e={e} />
        {e.viewers > 0 && <span className="card-viewers"><span className="viewer-dot" /> {e.viewers}</span>}
        <span className="card-play" aria-hidden="true">▶</span>
      </div>
      <div className="card-body">
        <span className="card-league">{icon} {e.league}</span>
        <h3 className="card-title">{teams}</h3>
        {e.score_ft && Array.isArray(e.score_ft) && <div className="card-score">{e.score_ft.join(' - ')}</div>}
      </div>
    </Link>
  );
}

function Rail({ events, liveFirst }) {
  if (!events?.length) return null;
  return (
    <div className="rail">
      {events.map((e) => <StreamCard key={e.stream_id} e={e} />)}
    </div>
  );
}

function LeagueSection({ name, icon, events }) {
  if (!events?.length) return null;
  const sorted = [...events].sort((a, b) => {
    const ta = a.start ? new Date(a.start).getTime() : Infinity;
    const tb = b.start ? new Date(b.start).getTime() : Infinity;
    return ta - tb;
  });
  return (
    <section className="league-section">
      <h2 className="league-heading">{icon} {name} <span className="league-count">{sorted.length}</span></h2>
      <Rail events={sorted} />
    </section>
  );
}

export default function Home() {
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [staleFlag, setStaleFlag] = useState(false);
  const [sport, setSport] = useState('all');
  const [q, setQ] = useState('');

  const load = async (isRefresh = false) => {
    if (!isRefresh) setLoading(true);
    try {
      const params = new URLSearchParams();
      if (sport !== 'all') params.set('sport', sport);
      if (q) params.set('q', q);
      const res = await fetch(`/api/streams?${params}`);
      if (!res.ok) throw new Error('liste alınamadı');
      const json = await res.json();
      setData(json);
      setStaleFlag(!!json.stale);
      setError(null);
    } catch (e) {
      if (!data) setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  // debounce arama/sport değişikliği — her tuşta ağa gitme
  useEffect(() => {
    const t = setTimeout(() => load(), 350);
    return () => clearTimeout(t);
  }, [sport, q]);
  useEffect(() => {
    const t = setInterval(() => load(true), 30000);
    return () => clearInterval(t);
  }, [sport, q]);
  const { liveEvents, upcomingEvents, otherEvents, sports } = useMemo(() => {
    if (!data) return { liveEvents: [], upcomingEvents: [], otherEvents: [], sports: [] };
    const all = Object.values(data.sports || {}).flatMap((v) => v.events);
    // global sort: live (by game_time desc) -> upcoming (by start asc) -> unknown
    const g = (e) => e.status === 'live' ? 0 : e.status === 'upcoming' ? 1 : 2;
    const key = (e) => {
      if (e.status === 'live') {
        const [h, m, s] = String(e.game_time || '0').split('.').join(':').split(':').map(Number);
        return -(h * 3600 + (m || 0) * 60 + (s || 0));
      }
      if (e.status === 'upcoming') return new Date(e.start).getTime();
      return Infinity;
    };
    all.sort((a, b) => g(a) - g(b) || key(a) - key(b));
    return {
      liveEvents: all.filter((e) => e.status === 'live'),
      upcomingEvents: all.filter((e) => e.status === 'upcoming'),
      otherEvents: all.filter((e) => e.status === 'unknown'),
      sports: Object.entries(data.sports || {}).map(([k, v]) => ({ key: k, count: v.count })).sort((a, b) => b.count - a.count),
    };
  }, [data]);

  const sectionEvents = useMemo(() => {
    const all = [...liveEvents, ...upcomingEvents, ...otherEvents];
    const byLeague = new Map();
    for (const e of all) {
      const k = e.league || 'Diğer';
      if (!byLeague.has(k)) byLeague.set(k, []);
      byLeague.get(k).push(e);
    }
    return [...byLeague.entries()]
      .sort((a, b) => {
        const g = (evs) => Math.min(...evs.map((e) => e.status === 'live' ? 0 : e.status === 'upcoming' ? 1 : 2));
        return g(a[1]) - g(b[1]);
      });
  }, [liveEvents, upcomingEvents, otherEvents]);

  return (
    <div className="page">
      <header className="site-header">
        <div className="shell header-inner">
          <Link to="/" className="brand">
            <img src="/logo.svg" alt="MultiSportsHD" className="brand-logo" />
          </Link>
          <div className="search" role="search">
            <span aria-hidden="true">🔍</span>
            <input type="search" placeholder="Lig, takım veya maç ara…" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Yayın ara" />
          </div>
          <span className="header-live"><span className="header-live-dot" /> {data?.live_total ?? '…'} CANLI</span>
        </div>
      </header>

      <nav className="cat-bar" aria-label="Spor kategorileri">
        <div className="shell cat-scroll">
          <button className={`cat-chip ${sport === 'all' ? 'active' : ''}`} onClick={() => setSport('all')}>Tümü <span className="count">{data?.total ?? ''}</span></button>
          {sports.map((s) => (
            <button key={s.key} className={`cat-chip ${sport === s.key ? 'active' : ''}`} onClick={() => setSport(s.key)}>
              {SPORT_ICON[s.key] || '📺'} {s.key.replace(/_/g, ' ')} <span className="count">{s.count}</span>
            </button>
          ))}
        </div>
      </nav>

      <main className="page-main shell">
        {!loading && data && !q && !sport && data.stale && (
          <div className="notice">ℹ️ Liste arka planda güncelleniyor — mevcut liste anında gösterildi.</div>
        )}

        {loading && (
          <div className="skeleton-grid" aria-label="Yükleniyor">
            {Array.from({ length: 12 }).map((_, i) => (
              <div className="skeleton" key={i}><div className="skeleton-media" /><div className="skeleton-line" /><div className="skeleton-line short" /></div>
            ))}
          </div>
        )}

        {!loading && error && !data && (
          <div className="state-box">
            <div className="state-icon">⚠️</div>
            <p>Yayın listesi alınamadı.</p>
            <div className="state-actions"><button className="btn primary" onClick={() => load()}>Tekrar dene</button></div>
          </div>
        )}

        {!loading && data && (
          <>
            {liveEvents.length > 0 && (
              <section className="top-section">
                <h2 className="section-heading"><span className="live-pulse" /> Şu an oynanıyor <span className="section-count">{liveEvents.length}</span></h2>
                <Rail events={liveEvents} />
              </section>
            )}
            {upcomingEvents.length > 0 && (
              <section className="top-section">
                <h2 className="section-heading">🕐 Yaklaşan <span className="section-count">{upcomingEvents.length}</span></h2>
                <Rail events={upcomingEvents} />
              </section>
            )}
            <div className="section-divider" />
            {sectionEvents.map(([league, evs]) => {
              const icon = SPORT_ICON[evs[0]?.sport_key] || '📺';
              return <LeagueSection key={league} name={league} icon={icon} events={evs} />;
            })}
            {liveEvents.length + upcomingEvents.length + otherEvents.length === 0 && (
              <div className="state-box">
                <div className="state-icon">📭</div>
                <p>{q ? `"${q}" için sonuç yok.` : 'Şu anda yayın yok.'}</p>
                {q && <button className="btn" onClick={() => setQ('')}>Aramayı temizle</button>}
              </div>
            )}
          </>
        )}
      </main>

      <footer className="site-footer">
        <div className="shell">MultiSportsHD — canlı ve yaklaşan spor yayınları</div>
      </footer>
    </div>
  );
}
